#ifndef MSG_H
#define MSG_H
#include <iostream>
#include<string.h>
#include "slist.h"
using namespace std;
class msg{
public:
	msg(){};
	msg(ifstream &in,char *str);
	void setId(long int id);
	void setDLC(int DLC);
	void setName(string name);
	void setSyn(string s);
	void setSgnList(slist *list);
	long int getId();
	int getDLC();
	string getName();
	string getSyn();
	void toString();
	slist* getSgnList();
private:
	long int ID;
	int DLC;
	string name;
	string syntax;
	slist *sgn_list;
};

#endif