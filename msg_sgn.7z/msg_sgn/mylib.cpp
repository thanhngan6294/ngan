#include "mylib.h"

using namespace std;
extern bool compare_arr(char *str_1 , char *str_2)
{
	if(strlen(str_1)==strlen(str_2)){
		for(int i=0;i<strlen(str_1);i++){
		if(str_1[i]!=str_2[i]) return false;
		}
	    return true;
	}
	else{
	return false;
	}

}