/*----------------------------
Created by :	 CAN
File name :		 Source.cpp

---------------------------------*/
#include <iostream>
#include <fstream>
#include<stdio.h>
#include <string>
#include "msg.h"
#include <stdlib.h>
#include "slist.h"
#include "msg_sgn.h"
#include "mylib.h"
using namespace std;
void output(void *data);
void saveFile_signal(ofstream &out,void *data);
void saveFile(ofstream &out,void *data);
slist * getMessage(ifstream &in);
int main(){
	ofstream out;
	ifstream in;
	char *name;
	char path[]="C:/Users/DINHTUYEN/Desktop/can database/";
	in.open("C:/Users/DINHTUYEN/Desktop/can database/a.txt");
	slist *msg_list=getMessage(in);
	//slist *msged_sgn_list=NULL;
	
	cout<<"danh sach message : "<<endl;
	out_put_list_data(msg_list,output);
	in.close();
	cout<<"nhap ten file"<<endl;
	name= (char*) malloc(sizeof(char));
	cin.getline(name,100);
	char *fullPath = (char*)malloc(sizeof(char)*(strlen(path)+strlen(name)+1));
	strcpy(fullPath,path);
	strcat(fullPath,name);
	out.open(fullPath);
	slistSaveFile(msg_list, out,saveFile);
	//slistSaveFile(msged_sgn_list, out,saveFile_signal);
	out.close();
	string s;
	system("pause");
	return 0;
}

void output(void *data){
	msg * m_msg= (msg*)data;
	m_msg->toString();
	}
void saveFile_signal(ofstream &out,void *data){
	msg_sgn * m_msg_sgn= (msg_sgn*)data;
	out<<" SG_ "<<m_msg_sgn->getName().c_str()<<" : "<<m_msg_sgn->getSbit()<<"|"<<m_msg_sgn->getLength()<<"@"
		<<m_msg_sgn->getByOrder()<<m_msg_sgn->getValType()<<" ("<<m_msg_sgn->getFactor()<<","<<m_msg_sgn->getOffset()<<") ["
		<<m_msg_sgn->getMin()<<"|"<<m_msg_sgn->getMax()<<"]"<<" \"\" "<<m_msg_sgn->getSyntax().c_str()<<endl;
}
void saveFile(ofstream &out,void *data){
	msg * m_msg= (msg*)data;
	out<<"BO_ "<<m_msg->getId()<<" "<<m_msg->getName().c_str()<<" "<<m_msg->getDLC()<<" "<<m_msg->getSyn().c_str()<<endl;
	slistSaveFile(m_msg->getSgnList(), out,saveFile_signal);
}

slist * getMessage(ifstream &in){
	slist *msg_list=NULL;
	char str[1000];
	int check = 0;
	
	int count=0;
	char *str1;
	while(!in.eof()){
		//if(count==4) break;
		if(check==0){
		in>>str;	
		}
		msg *message=NULL;
		if(compare_arr(str,"BO_")){
			count++;
			check=1;
			// make a message 
			message = new msg(in,str);
			message->toString();
			cout<<"message"<<endl;
			// create a slist to contain signals
			slist *msged_sgn_list=NULL;
			// add signal into the message we just made
			int check2=0;
			do{
				// redo this work until we get all the signal of above message
			if(!compare_arr(str,"SG_")){in>>str;}
			str1=str;
			cout<<str<<endl;
				if(compare_arr(str,"SG_")){
					cout<<"signal"<<endl;
				// create a signal 
				msg_sgn *msged_sgn = new msg_sgn(in,str);
				// add above signal into signal_list
				msged_sgn_list=slist_append(msged_sgn_list,(void *)msged_sgn);
				in>>str;
				//cout<<" check="<<str<<endl;
			}
				//cout<<"while1"<<endl;
			}while(compare_arr(str,"SG_"));
			// if signal_list be created successfully, set signal_list become messaged_signal_list
				if(msged_sgn_list){message->setSgnList(msged_sgn_list);}
			// add message into message_list to manage it more conveniently 
			msg_list=slist_append(msg_list,(void *)message);
		}else{
		check=0;
		}
		message =NULL;
		//cout<<"while2"<<endl;
	}
	return msg_list;
}