#include "msg_sgn.h"
#include <fstream>
#include <iostream>
#include "mylib.h"
#include"slist.h"
using namespace std;
// default constructor mehtods 
int msg_sgn::sgn_index=0;
msg_sgn::msg_sgn(){
	sgn_index++;
	this->setByteOrder(1);
	this->setValType('-');
	this->setFactor(1);
	this->setOffset(0);
	this->setLength(8);
	this->setMax(0);
	this->setMin(0);
	this->setName("New_Signal"+(char)sgn_index);
	this->setMux("");
	this->setSyntax("Vector__XXX");
	this->setUnit("");
	this->setSbit(0);
}
//constructor mehtods 
msg_sgn::msg_sgn(ifstream &in, char * str){
	char c;
	if(compare_arr(str,"SG_")){
	   // cout<<"so sanh dung !"<<endl;
		in.getline(str,100,' ');
		in.getline(str,100,' ');
		this->setName(str);
		in.getline(str,100,' ');
		in.getline(str,100,'|');
		this->setSbit(atoi(str));
		in.getline(str,100,'@');
		this->setLength(atoi(str));
		in.get(c);
		this->setByteOrder(c);
		in.get(c);
		this->setValType(c);
		in.getline(str,100,'(');
		in.getline(str,100,',');
		this->setFactor(atof(str));
		in.getline(str,100,')');
		this->setOffset(atoi(str));
		in.getline(str,100,'[');
		in.getline(str,100,'|');
		this->setMin(atoi(str));
		in.getline(str,100,']');
		this->setMax(atoi(str));
		in.getline(str,100,'"');
		in.getline(str,100,'"');
		this->setUnit(str);
		in.getline(str,100,' ');
		in.getline(str,100);
		this->setSyntax(str);
		this->toString();
	}

}
// set methods
void msg_sgn::setSbit(int s_bit){
	this->s_bit=s_bit;
}
void msg_sgn::setMux(string mux){
	this->mux=mux;}
void msg_sgn::setName(string name){
	this->name=name;}
void msg_sgn::setLength(int length){
	this->length=length;}
void msg_sgn::setByteOrder(char byteOrder){
	this->by_order=byteOrder;}
void msg_sgn::setValType(char valType){
	this->val_type=valType;}
void msg_sgn::setFactor(float factor){
	this->factor=factor;}
void msg_sgn::setOffset(int offset){
	this->offset=offset;}
void msg_sgn::setMin(int min){
	this->min=min;}
void msg_sgn::setMax(int max){
	this->max=max;}
void msg_sgn::setUnit(string unit){
	this->unit=unit;}
void msg_sgn::setSyntax(string syntax){
	this->syntax=syntax;}
// get methods
char msg_sgn::getByOrder(){
	return this->by_order;
}
string msg_sgn::getName(){
	return this->name;
}
string msg_sgn::getMux(){
	return this->mux;
}
string msg_sgn::getUnit(){
	return this->unit;
}
char msg_sgn::getValType(){
	return this->val_type;
}
float msg_sgn::getFactor(){
	return this->factor;
}
int msg_sgn::getLength(){
	return this->length;
}
int msg_sgn::getMax(){
	return this->max;
}
int msg_sgn::getMin(){
	return this->min;
}
int msg_sgn::getOffset(){
	return this->offset;
}
int msg_sgn::getSbit(){
	return this->s_bit;
}

string msg_sgn::getSyntax(){
	return this->syntax;
}

void msg_sgn::toString(){
	
	cout<<"SG_ "<<this->name.c_str()<<" : "<<this->s_bit<<"|"<<this->length<<"@"
		<<this->by_order<<this->val_type<<" ("<<this->factor<<","<<this->offset<<") ["
		<<this->min<<"|"<<this->max<<"]"<<" \"\" "<<this->syntax.c_str()<<endl;

}