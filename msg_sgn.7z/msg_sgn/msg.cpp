#include <iostream>
#include "msg.h"
#include<string.h>
#include<fstream>
#include "mylib.h"
#include "slist.h"
using namespace std;
msg::msg(ifstream &in, char *str){

		if(compare_arr(str,"BO_")){
			in.getline(str,100,' ');
			in.getline(str,100,' ');
			this->setId(atol(str));
			in.getline(str,100,':');
			this->setName(str); 
			in.getline(str,100,' ');
			in.getline(str,100,' ');
			this->setDLC(atoi(str));
			in.getline(str,100);
			this->setSyn(str);
			//this->toString();
		}		
}
void msg::setId(long int id){
	this->ID=id;
}
void msg::setDLC(int DLC){
	this->DLC=DLC;
}
void msg::setName(string name){
	this->name=name;
}
void msg::setSyn(string s){
	this->syntax=s;
}
void msg::setSgnList(slist *list){
	this->sgn_list=list;
}
long int msg::getId(){
	return this->ID;
}
int msg::getDLC(){
	return this->DLC;
}
string msg::getName(){
	return this->name;
}
string msg::getSyn(){
	return this->syntax;
}
slist* msg::getSgnList(){
	return this->sgn_list;}
void msg::toString(){
	//printf("%s",name);
	cout<<"ID : "<<this->getId()<<endl;
	cout<<"Name : "<<this->getName().c_str()<<endl;
	cout<<"DLC : "<<this->getDLC()<<endl;
	cout<<"Syntax : "<<this->getSyn().c_str()<<endl;
}
