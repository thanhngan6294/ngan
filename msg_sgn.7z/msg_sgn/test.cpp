#include <iostream>
#include<string.h>
#include<fstream>
#include"mylib.h"
using namespace std;
int main(){
	ofstream out ;
	out.open("C:/Users/DINHTUYEN/Desktop/can database/b.txt");
	ifstream in;
	in.open("C:/Users/DINHTUYEN/Desktop/can database/a.dbc");
	char str[100];
	char line[1000];
	while(!in.eof()){
		cout<<"while 2"<<endl;
			if(compare_arr(str,"BO_"))
			{
			in.getline(line,100);
			cout<<line<<endl;
			}
		do{
			in>>str;
			if(compare_arr(str,"SG_"))
			{
			in.getline(line,100);
			cout<<line<<endl;
			//in>>str;
			}
			if(compare_arr(str,"CM_"))
				{
					cout<<"break"<<endl;
					break;
			}
			cout<<"while 1"<<endl;
		}while(!compare_arr(str,"BO_"));
		cout<<"done!"<<endl;
		if(compare_arr(str,"CM_")) break;
	}

	system("pause");
	return 0;
}