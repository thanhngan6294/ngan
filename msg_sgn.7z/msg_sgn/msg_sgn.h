#ifndef MSG_SGN
#define MSG_SGN


#include <iostream>
#include<string.h>
using namespace std;
class msg_sgn{
public:
	msg_sgn();
	msg_sgn(ifstream &in, char *str);
	
	void setSbit(int s_bit);
	void setMux(string mux);
	void setName(string name);
	void setLength(int length);
	void setByteOrder(char byteOrder);
	void setValType(char valType);
	void setFactor(float factor);
	void setOffset(int offset);
	void setMin(int min);
	void setMax(int max);
	void setUnit(string unit);
	void setSyntax(string syntax);
	int getSbit();
	string getMux();
	string getName();
	int getLength();
	char getByOrder();
	char getValType();
	float getFactor();
	int getOffset();
	int getMin();
	int getMax();
	string getUnit();
	string getSyntax();
	void toString();
private:
	int s_bit;
	string mux;
	string name;
	int length;
	char by_order;
	char val_type;
	float factor;
	int offset;
	int min;
	int max;
	string unit;
	string syntax;
	static int sgn_index;
};
#endif // !MSG_SGN