#ifndef MYLIB_H
#define MYLIB_H


#include <iostream>
#include <string.h>
using namespace std;

bool compare_arr(char *a,char *b);
#endif // !MYLIB_H