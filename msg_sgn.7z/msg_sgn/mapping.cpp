#include <iostream>
#include "mapping.h"
#include<string.h>
#include<fstream>
using namespace std;
mapping::mapping(){
	mapping obj;
	//if(strcmp 
}