#include <stdio.h>
#include <string.h>
#include <stdlib.h>
  typedef struct index_arr{
	char ** arr;
	int index;
} index_arr ;
index_arr split(char str[])
{
        int index = 0;
        int i;
        char **b = (char **)malloc(100*sizeof(char));
        char *p;
        p = strtok(str, "|,[]()\"@: "); //cat chuoi bang cac ky tu ,. va space
        while(p != NULL)
        {
                b[index] = p;
                index++;
                p = strtok(NULL, "|,[]()\"@: "); //cat chuoi tu vi tri dung lai truoc do
        }
	   index_arr result;
	   result.arr=b;
	   result.index=index;
        return result ;
}