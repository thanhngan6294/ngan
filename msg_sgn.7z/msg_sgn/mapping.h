#ifndef MAPPING_H
#define MAPPING_H
#include <iostream>
#include<string.h>
#include<cstdint>
using namespace std;
class mapping{
public:
	mapping();
private:
	string name;
	string syntax;
};

#endif